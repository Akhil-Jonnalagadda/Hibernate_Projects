package com.util;

public class Constants {
	public static String url="jdbc:mysql://localhost:3306/Akhil";
	public static String username="root";
	public static String password="nainikabodapati@123";
}
