package com.metadeta;
import java.sql.*;

import com.util.JdbcUtil;
public class Metadata {

	public static void main(String[] args) throws Exception{
		try {
  JdbcUtil j = new JdbcUtil();
  Connection c = j.getConnection();
  String query = "Select * from bar";
  PreparedStatement statement = c.prepareStatement(query);
  ResultSet rs =statement.executeQuery(query);
  // to get the metadata
  ResultSetMetaData metaData = rs.getMetaData();
  System.out.println("Column count: "+ metaData.getColumnCount());
  System.out.println("ColumnName: "+ metaData.getColumnName(1)+"\t"+metaData.getColumnName(2)+"\t\t"+metaData.getColumnName(3)+metaData.getColumnName(4));
	
  System.out.println(metaData.getTableName(1));
  System.out.println(metaData.getColumnTypeName(1));
  System.out.println(metaData.getColumnType(1));
  
  // to see the n number of the metadata names by using the for loop
	/*
	 * int count =metaData.getColumnCount(); 
	 * for(int i=1;i<=count;i++) {
	 * System.out.print(metaData.getColumnName(i)); }
	 */
  
  
  while(rs.next()) {
			System.out.println("bar_id"+"   \t  "+"bar_name"+"   \t   "+"bar_date"+"   \t   "+ "bar_income");
			System.out.println(rs.getInt(1)+"        \t   "+rs.getString(2)+"      \t         "+rs.getDate(3)+"    \t     "+rs.getInt(4));	
		
		}
		
		 
		
		System.out.println("reached .... !");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
  
	}

}
