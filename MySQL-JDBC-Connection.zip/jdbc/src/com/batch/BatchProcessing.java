package com.batch;
import com.util.JdbcUtil;
import java.sql.*;
public class BatchProcessing {
	public static void main(String[] args) throws Exception{
		JdbcUtil jc = new JdbcUtil();
		Connection con = jc.getConnection();
		PreparedStatement st  = con.prepareStatement("Insert into employees values(?,?,?,?)");
		st.setInt(1, 13);
		st.setString(2,"sri");
		st.setString(3,"sri@gmail.com");
		st.setDouble(4,55000.00);
		//t.executeUpdate();
		st.addBatch();
		st.setInt(1, 14);
		st.setString(2,"srilatha");
		st.setString(3,"srilatha@gmail.com");
		st.setDouble(4,55000.00);
		st.addBatch();
		st.executeBatch();
		

		
		System.out.println("updated...");
		
	}

}
