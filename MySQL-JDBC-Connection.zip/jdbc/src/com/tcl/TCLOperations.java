package com.tcl;
import com.util.JdbcUtil;
import java.sql.*;
public class TCLOperations {

	public static void main(String[] args) throws Exception {
	Connection con =null; //we have taken this to set the rollback in the catch block; 
		try {
		JdbcUtil jd =new JdbcUtil();
		 con = jd.getConnection();
		con.setAutoCommit(false);
		PreparedStatement statement = con.prepareStatement("update bar set bar_income = ? where bar_id =?");
		statement.setInt(1,7000);
		statement.setInt(2, 5);
		statement.executeUpdate();
		System.out.println("Updated..");
		
		con.commit();
		con.rollback();
		
		}catch(Exception e) {
		//	System.out.println(e.getMessage());
		
			con.rollback();
		}
	}
}
