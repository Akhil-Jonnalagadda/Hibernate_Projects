/*
 * package com.callable; import com.util.JdbcUtil; import java.sql.*; import
 * java.util.concurrent.Callable; public class StoredProcedures throws
 * Exception{
 * 
 * public static void main(String[] args) { JdbcUtil jdbcUtil = new JdbcUtil();
 * Connection con = jdbcUtil.getConnection(); //con.preparecall("") Callable
 * statement = con.callablestatement(S);/ we need to write the stored procedure
 * inside the prepare call with {} }
 * 
 * }
 */