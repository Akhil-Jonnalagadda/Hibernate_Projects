package jdbc.akhil;
import java.sql.*;
public class FirstClass {

	public static void main(String[] args) throws ClassNotFoundException,  SQLException {
				Class.forName("com.mysql.cj.jdbc.Driver");
				System.out.println("driver started");

				
				  String url="jdbc:mysql://localhost:3306/sri"; String username="root"; String
				  password="nainikabodapati@123";
				 
				Connection con = DriverManager.getConnection(url,username,password);
				Statement statement = con.createStatement();
		//String Query ="insert into bar values(3,'mmr','2023-06-10',50000)";
			//String Query ="delete from bar where bar_id =2";
				String Query ="update bar set bar_income=102000 where bar_id =2";
				statement.executeUpdate(Query);
				System.out.println("reached.....!!!");
				statement.close();
				con.close();
			
				
				
	}

}
