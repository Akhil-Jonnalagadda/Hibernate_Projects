package jdbc.dql;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;

import com.util.JdbcUtil;
public class DQLOperations {

	public static void main(String[] args) throws SQLException {
		try {
	JdbcUtil jdbc = new JdbcUtil();
	Connection con =jdbc.getConnection();
	Statement statement =con.createStatement();
	//String Query = "insert into bar values(7,'mnk','2024-09-09',9000)";
	String Query ="select * from bar";
    ResultSet rs = statement.executeQuery(Query);
	while(rs.next()) {
		int bar_id = rs.getInt("bar_id");
		String bar_name= rs.getString("bar_name");
		int bar_income =rs.getInt("bar_income");
		System.out.println("bar_id\tbar_name\tbar_income");
		System.out.println(bar_id + "  \t  "+ bar_name+ "  \t  "+bar_income);
	}
		
		
	System.out.println("reached ...");
	
	/*
	 * String query = "insert into bar values(8,'mnk','2024-09-09',9000)";
	 * PreparedStatement statement =con.prepareStatement(query);
	 */
	
	
	
		}catch(Exception e) {
		System.out.println(e.getMessage());
		}
		}
		

}
