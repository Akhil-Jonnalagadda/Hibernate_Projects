package com.hql;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.MutationQuery;
import org.hibernate.query.SelectionQuery;   // import org.hibernate.*;              // Imports all classes in org.hibernate package       // import org.hibernate.query.*;  

import com.model.student;
import com.util.HibernateUtil;

public class Hql {
//Hibernate Query Language 
	
	public static void main(String[] args) {
		SessionFactory sessionFactory =HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		//select(session); //hit ctrl+1 and then enter it will create for us automatically method
	//	selectwithwhere(session);
		 // insert(session);
	//update(session);
		
		session.beginTransaction();
		MutationQuery query = session.createMutationQuery("delete from student where studentId=?1");
		query.setParameter(1,1);
		query.executeUpdate();  
		
		session.getTransaction().commit();
		}

	private static void update(Session session) {
		session.beginTransaction();
		MutationQuery query = session.createMutationQuery("update student set marks =?1 where studentId=?2");
		query.setParameter(1, 100);
		query.setParameter(2, 1);
		
		query.executeUpdate();
		session.getTransaction().commit();
	}

	private static void  insert(Session session) {
		session.beginTransaction();
		 MutationQuery query= session.createMutationQuery("Insert into student( name, marks) values(?1,?2)");
		// query.setParameter(1, 4);
		 query.setParameter(1 ,"Roshini");
		 query.setParameter(2, 89);
		 
		 query.executeUpdate();
		 session.getTransaction().commit();
	}

	private static void selectwithwhere (Session session) {
		SelectionQuery<student> query = session.createSelectionQuery(" From student where studentId=?1 ",student.class);
		query.setParameter(1, 1);
		List<student> list = query.list();
		System.out.println(list);
	}

	private static void select(Session session) {
		SelectionQuery<student> query = session.createSelectionQuery(" From student ",student.class);
	List<student> list =	query.list();
	System.out.println(list);
	}
}

// DQL
//Select - session.createSelectionQuery()
//DML
//Insert, update , delete - session.createMutationQuery();
