package com.namedqueries;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.MutationQuery;
import org.hibernate.query.Query;

import com.model.student;
import com.util.HibernateUtil;

public class ApplicationNq {

	public static void main(String[] args) {
SessionFactory sessionFactory =  HibernateUtil.getSessionFactory();
Session session = sessionFactory.openSession();
/*
 * Query<student> query = session.createNamedQuery("allstudents",student.class);
 * List<student> list = query.list(); System.out.println(list);
 */

session.beginTransaction();
MutationQuery query2=session.createNamedMutationQuery("updatestudent");
query2.setParameter("name", "mohan p");
query2.setParameter("studentId",2);
query2.executeUpdate();
session.getTransaction().commit();

	}

}
