package com.model;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;

@Entity
public class car {
	@EmbeddedId
private carId carId;
	private String companyName;
	private double price;
	public car() {
		
	}
	public car(com.model.carId carId, String companyName, double price) {
		super();
		this.carId = carId;
		this.companyName = companyName;
		this.price = price;
	}
	public carId getCarId() {
		return carId;
	}
	public void setCarId(carId carId) {
		this.carId = carId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "car [carId=" + carId + ", companyName=" + companyName + ", price=" + price + "]";
	}
	
}
