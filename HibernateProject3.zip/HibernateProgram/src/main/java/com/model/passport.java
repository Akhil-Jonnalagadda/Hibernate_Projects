package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class passport {
	@Id
	private int passportNumber;
	private String issuedPlace;
	public passport() {
		
	}
	public passport(int passportNumber, String issuedPlace) {
		super();
		this.passportNumber = passportNumber;
		this.issuedPlace = issuedPlace;
	}
	@Override
	public String toString() {
		return "passport [passportNumber=" + passportNumber + ", issuedPlace=" + issuedPlace + "]";
	}
	public int getPassportNumber() {
		return passportNumber;
	}
	public void setPassportNumber(int passportNumber) {
		this.passportNumber = passportNumber;
	}
	public String getIssuedPlace() {
		return issuedPlace;
	}
	public void setIssuedPlace(String issuedPlace) {
		this.issuedPlace = issuedPlace;
	}

}
