package com.model;

import jakarta.persistence.Embeddable;

@Embeddable
public class carId {
private int id;
private String engineNumber;
public carId() {
	
}
public carId(int id, String engineNumber) {
	super();
	this.id = id;
	this.engineNumber = engineNumber;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getEngineNumber() {
	return engineNumber;
}
public void setEngineNumber(String engineNumber) {
	this.engineNumber = engineNumber;
}
@Override
public String toString() {
	return "carId [id=" + id + ", engineNumber=" + engineNumber + "]";
}


}
