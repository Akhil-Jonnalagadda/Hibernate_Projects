package com.Embeddable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.model.car;
import com.model.carId;
import com.util.HibernateUtil;

public class Application {
public static void main(String[] args) {
	SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	Session session = sessionFactory.openSession();
insert(session);
	car c = session.find(car.class, new carId(1,"1h22223b33")); //it is a composite key so thats we are passing the object.
	System.out.println(c);
	
}

private static void insert(Session session) {
	session.beginTransaction();
	car c = new car(new carId(2,"1h22223b33"),"bmw",1000);
	session.persist(c);
	session.getTransaction().commit();
}

}
