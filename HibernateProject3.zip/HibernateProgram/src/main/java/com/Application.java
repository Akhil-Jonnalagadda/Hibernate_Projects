package com;


import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.model.student;
import com.util.HibernateUtil;

public class Application {

	public static void main(String[] args) {
SessionFactory sessionFactory =HibernateUtil.getSessionFactory();
Session session = sessionFactory.openSession();
student st = new student("akhil",22);
student st1 = new student("waste",25);
student st2 = new student("fellow",28);
session.beginTransaction();
session.persist(st);
session.persist(st1);
session.persist(st2);
session.getTransaction().commit();
session.close();


	}

}
//hibernate.hbm2ddl.auto"> create don't do it in real time.
//before creating it will drop the table
//hibernate.hbm2ddl.auto"> update
//it will create if doesn't exists
// if table exists it will update the data

//hibernate.hbm2ddl.auto"> none --it doesn't do anything
//hibernate.hbm2ddl.auto"> createdrop  once session close table will drop automatically. 


