package com.Native;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.MutationQuery;
import org.hibernate.query.NativeQuery;

import com.model.student;
import com.util.HibernateUtil;

public class Native {
	public static void main(String[] args) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session =sessionFactory.openSession();
		//session.beginTransaction();
		//select(session);
	/*
	 * query.setParameter(1, 1); query.executeUpdate();
	 * session.getTransaction().commit();
	 */
	//	insert(session);
		
		
		 // updated(session);
	//	DML-- session.createNativeMutationQuery()
		// DQL-session.createNativeQuery(" ")
		 
			
			  session.beginTransaction(); MutationQuery query=session.createNativeMutationQuery(" delete from student where studentId=?1");
			  query.setParameter(1, 2); 
			  query.executeUpdate(); 
			  session.getTransaction().commit();
			 
	}

	private static void updated(Session session) {
		session.beginTransaction(); 
		  MutationQuery query=session.createNativeMutationQuery(" update student set name=?1 where studentId=?2");
		  query.setParameter(1, "rapo"); 
		  query.setParameter(2,2);
		  query.executeUpdate(); 
		  session.getTransaction().commit();
	}

	private static void insert(Session session) {
		session.beginTransaction();
		MutationQuery	query=session.createNativeMutationQuery(" insert into student(name,marks) values(?1,?2)");
		query.setParameter(1, "hello");
		query.setParameter(2,33);
		query.executeUpdate();
		session.getTransaction().commit();
	}

	private static void select(Session session) {
		NativeQuery<student>	query=session.createNativeQuery("select * from student",student.class);
		List<student> list = query.list();
		System.out.println(list);
	}

}
