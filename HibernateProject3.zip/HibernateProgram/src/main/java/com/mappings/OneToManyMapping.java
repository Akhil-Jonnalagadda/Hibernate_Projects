package com.mappings;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.model.Order;
import com.model.Person;
import com.util.HibernateUtil;

public class OneToManyMapping {

	public static void main(String[] args) {
	SessionFactory sessionFactory =HibernateUtil.getSessionFactory();
	Session session = sessionFactory.openSession();
	Person person = new Person("akhil","21344");
	Order order = new Order(1, "Readmi mobile",1);
	Order order2 = new Order(2,"Dell Laptop,11");
	order.setPerson(person);
	Order2.setPerson(person); 
	
	List<Order> orders = new ArrayList<Order>();
	orders.add(order);
	orders.add(order2);
	person.setOrders(orders);
	
	

	}

}
