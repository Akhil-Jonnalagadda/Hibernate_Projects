package com.mappings;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.model.Trainee;
import com.model.course;
import com.util.HibernateUtil;

public class MantToManyMapping {

	public static void main(String[] args) {
		SessionFactory sessionFactory =HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		List<Trainee> trainees1 = new ArrayList<Trainee>();
		List<Trainee> trainees2 = new ArrayList<Trainee>();
		Trainee t1 = new Trainee("akhil");
		Trainee t2 = new Trainee("Jagadeesh");
		course c1 = new course("JFS");
		course c2 = new course("ADS")
				trainees1.add(t1);
		trainees2.add(t2);

	}

}
