package com.mappings;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.model.User;
import com.model.passport;
import com.util.HibernateUtil;

public class OneToOneMapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
Session session = sessionFactory.openSession();

//User u = session.find(User.class,1);

/*
 * User u = new User("akhil", new passport(1000,"vizag") );
 * session.beginTransaction(); session.persist(u);
 * session.getTransaction().commit();
 */
 session.remove(new User(1,"",new passport(1000," ")))

}

}
// one to one mapping 
//one to many mapping 