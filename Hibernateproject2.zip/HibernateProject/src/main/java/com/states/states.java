package com.states;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.model.students;
import com.util.HibernateUtil;
public class states {

	public static void main(String[] args) {
	SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	students st = new students(10,"df","df@gmail.com");// Transient
	//students st = new students(11,"dfa","dfa@gmail.com");
	Session session =sessionFactory.openSession();
	session.beginTransaction();
	session.persist(st); //persistent state , dirty check will happen , when try it change something it will do persistent checking
	session.getTransaction().commit();
	session.close();
	st.setEmail("aaaa@gmail.com"); // detached state
	
	

	}

}
