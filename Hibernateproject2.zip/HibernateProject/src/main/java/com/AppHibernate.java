package com;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.model.students;
import com.util.HibernateUtil;

public class AppHibernate {
	public static void main(String[] args) {
		getData();
		updateData();
		deleteData();
		/*
		 * Configuration cfg= new Configuration(); cfg.configure("hibernate.cfg.xml");
		 * cfg.addAnnotatedClass(students.class);
		 */
		/*
		 * SessionFactory sessionFactory =HibernateUtil.getSessionFactory();
		 * 
		 * 
		 * Session session =sessionFactory.openSession(); // Students st = new
		 * Students(1,"akhil","akhil@gmail.com"); List<students> empList = new
		 * ArrayList<>(); empList.add(new students(5, "brahmi", "brahmi@gmail.com"));
		 * empList.add(new students(6, "srilatha", "srilatha@gmail.com"));
		 * empList.add(new students(7, "arjun", "arjun@gmail.com")); empList.add(new
		 * students(8, "jack", "jack@gmail.com"));
		 * 
		 * session.beginTransaction();
		 * 
		 * for (students emp : empList) { session.persist(emp); } //
		 * session.persist(empList); // it will insert and save
		 * session.getTransaction().commit(); System.out.println("Inserted");
		 */

	}

	public static void getData() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		students st = session.find(students.class, 20);// to view we don't need to commit anything. dql 
		System.out.println(st);

	}
	public static void updateData() {
		SessionFactory sessionFactory =HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		//students std = new students();
		students st = session.find(students.class, 2);// first we need to get the data and need to update the data
	//	st.setId(2);
		st.setEmail("lucky@gmail.com");
		session.beginTransaction();
		//whenever we want to update we use merge
		session.merge(st);
		session.getTransaction().commit();
		System.out.println("Inserted...");
	//	Dirty checking whenever we load the data from database, if we change we don't need to merge we can merge it back  we don't need to commit it will automatically   
	// i happen due to persistent objects
		//states in hibernate : there are 3 states  hybernate lifecycle 1. Transient state, persistent state, detached state
		//1. not accociated with any session -- dirty 
		//persistent - object is associated with any session
		//detached state: objects gets detached when session is closed
	}
	public static void deleteData() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session =sessionFactory.openSession();
	//	students st = session.find(students.class, 8);
	
		students st = new students(8,"","");
		session.beginTransaction();
		session.remove(st);
		session.getTransaction().commit();
		
		
	}

}
