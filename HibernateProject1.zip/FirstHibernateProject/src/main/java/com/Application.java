package com;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import com.model.Employees;
public class Application {

	public static void main(String[] args) {
	Configuration cfg= new Configuration();
	cfg.configure("hibernate.cfg.xml");
	cfg.addAnnotatedClass(Employees.class);
SessionFactory sessionFactory =cfg.buildSessionFactory();

Session session =sessionFactory.openSession();
List<Employees> empList = new ArrayList<>();
empList.add(new Employees(1, "akhil", "akhil@gmail.com", 29000));
empList.add(new Employees(2, "rahul", "rahul@gmail.com", 31000));
empList.add(new Employees(3, "megha", "megha@gmail.com", 45000));
empList.add(new Employees(4, "john", "john@gmail.com", 38000));

session.beginTransaction();

for (Employees emp : empList) {
    session.persist(emp);  // ✅ persist each entity, not the list
}
// session.persist(empList); // it will insert and save
session.getTransaction().commit();
System.out.println("Inserted");

	}

}
